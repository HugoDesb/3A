void print_arbre_prefixe ( t_ptr_arbre arbre ) ;
