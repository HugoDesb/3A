t_ptr_arbre cree_feuille ( int valeur ) ;
int val_feuille ( t_ptr_arbre arbre ) ;
int est_feuille ( t_ptr_arbre arbre ) ;
t_ptr_arbre cree_noeud ( t_ptr_arbre gauche , t_ptr_arbre droit , char etiquette ) ;
t_ptr_arbre arbre_fg ( t_ptr_arbre arbre ) ;
t_ptr_arbre arbre_fd ( t_ptr_arbre arbre ) ;
char arbre_etiq ( t_ptr_arbre arbre ) ;
