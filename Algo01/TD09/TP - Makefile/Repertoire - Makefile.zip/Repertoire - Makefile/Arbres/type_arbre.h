typedef struct mmmm
        {int feuille ;
         int val ;
         char etiq ;
         struct mmmm * fg ;
         struct mmmm * fd ;
        }
struct_arbre , * t_ptr_arbre ;
