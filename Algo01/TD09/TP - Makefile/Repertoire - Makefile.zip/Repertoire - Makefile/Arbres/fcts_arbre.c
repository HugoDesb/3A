#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <malloc.h>

#include "type_arbre.h"

/* -------------------------------------------- */

t_ptr_arbre cree_feuille ( int valeur ) ;
int val_feuille ( t_ptr_arbre arbre ) ;
int est_feuille ( t_ptr_arbre arbre ) ;
t_ptr_arbre cree_noeud ( t_ptr_arbre gauche , t_ptr_arbre droit , char etiquette ) ;
t_ptr_arbre arbre_fg ( t_ptr_arbre arbre ) ;
t_ptr_arbre arbre_fd ( t_ptr_arbre arbre ) ;
char arbre_etiq ( t_ptr_arbre arbre ) ;

/* -------------------------------------------- */

t_ptr_arbre cree_feuille ( int valeur )
           {t_ptr_arbre nouv ;
            nouv = (t_ptr_arbre)malloc( sizeof( struct_arbre ) ) ;
            nouv->feuille = 1 ;
            nouv->val = valeur ;
            return( nouv ) ;
           }

int val_feuille ( t_ptr_arbre arbre )
    {assert( est_feuille ( arbre ) ) ;
     return( arbre->val ) ;
    }

int est_feuille ( t_ptr_arbre arbre )
    {return( arbre->feuille ) ;
    }

t_ptr_arbre cree_noeud ( t_ptr_arbre gauche , t_ptr_arbre droit , char etiquette )
            {t_ptr_arbre nouv ;
             nouv = (t_ptr_arbre)malloc( sizeof( struct_arbre ) ) ;
             nouv->feuille = 0 ;
             nouv->etiq = etiquette ;
             nouv->fg = gauche ;
             nouv->fd = droit ;
             return( nouv );
            }

t_ptr_arbre arbre_fg ( t_ptr_arbre arbre )
            {assert( ! est_feuille( arbre ) ) ;
             return( arbre->fg ) ;
            }

t_ptr_arbre arbre_fd ( t_ptr_arbre arbre )
            {assert( ! est_feuille( arbre ) ) ;
             return( arbre->fd ) ;
            }

char arbre_etiq ( t_ptr_arbre arbre )
     {assert( ! est_feuille( arbre ) ) ;
      return( arbre->etiq ) ;
    }
