#include <stdio.h>
#include <stdlib.h>

/* -------------------------------------------- */

#include "type_arbre.h"
#include "type_liste.h"

#include "fcts_liste.h"
#include "fcts_arbre.h"
#include "fonctions.h"

/* -------------------------------------------- */

int main ( void ) ;

/* -------------------------------------------- */

int main ( void )
    {t_ptr_arbre arbre ;
     arbre = cree_noeud( cree_noeud( cree_feuille( 5 ) ,
                                     cree_noeud( cree_feuille( 6 ) ,
                                                 cree_feuille( 9 ) ,
                                                 '+' ) ,
                                     '*' ) ,
                         cree_noeud( cree_noeud( cree_noeud( cree_feuille( 15 ) ,
                                                             cree_feuille( 19 ) ,
                                                            '+' ) ,
                                                 cree_feuille( 10 ) ,
                                                 '*' ) ,
                                     cree_noeud( cree_feuille( 11 ) ,
                                                 cree_feuille( 13 ) ,
                                                 '/' ) ,
                                     '/' ) ,
                         '-' ) ;
     (void)printf( "Les noeuds et feuilles de l'arbre en parcours en largeur :\n" ) ;
     print_arbre_prefixe( arbre ) ;
     (void)printf( "\nBye !\n" ) ;
     return( 0 ) ;
    }
