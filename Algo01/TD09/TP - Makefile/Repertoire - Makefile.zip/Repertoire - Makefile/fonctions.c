#include <stdlib.h>
#include <stdio.h>

#include "type_arbre.h"
#include "type_liste.h"

#include "fcts_liste.h"
#include "fcts_arbre.h"

/* -------------------------------------------- */

void print_arbre_prefixe ( t_ptr_arbre arbre )
     {t_ptr_arbre traiter ;
      t_ptr_liste file ;
      file = (t_ptr_liste)NULL ;
      file = enfile( arbre , file ) ;
      while ( ! 
est_vide( file ) )
            {traiter = tete_file( file ) ;
             file = defile( file ) ;
             if ( est_feuille( traiter ) )
                (void)printf( "%d " , val_feuille( traiter ) ) ;
             else
                {(void)printf( "%c " , arbre_etiq( traiter ) ) ;
 		 file = enfile( arbre_fg( traiter ) , file ) ;
                 file = enfile( arbre_fd( traiter ) , file ) ;
                }
            }
     }
