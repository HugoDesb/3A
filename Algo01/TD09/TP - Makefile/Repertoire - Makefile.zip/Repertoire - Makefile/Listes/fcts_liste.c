#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <assert.h>

#include "type_arbre.h"
#include "type_liste.h"

t_ptr_liste cree_vide ( void )
            {return( (t_ptr_liste)NULL ) ;
            }

int est_vide ( t_ptr_liste liste )
    {return( liste == cree_vide() ) ;
    }

t_ptr_liste ajout_liste ( t_ptr_arbre val , t_ptr_liste liste )
            {t_ptr_liste nouv ;
             nouv = (t_ptr_liste)malloc( sizeof ( struct_liste ) ) ;
             nouv->element = val ;
             nouv->suiv = liste ;
             return( nouv ) ;
            }

t_ptr_arbre tete_liste ( t_ptr_liste liste )
          {assert( ! est_vide( liste ) ) ;
           return( liste->element ) ;
          }

t_ptr_liste queue_liste ( t_ptr_liste liste )
            {assert( ! est_vide( liste ) ) ;
             return( liste->suiv ) ;
            }

t_ptr_liste enfile ( t_ptr_arbre arbre , t_ptr_liste file )
            {t_ptr_liste nouv ;
             nouv = (t_ptr_liste)malloc( sizeof ( struct_liste ) ) ;
             nouv->element = arbre ;
             nouv->suiv = cree_vide( ) ;
             if ( est_vide( file ) )
                return( nouv ) ;
	     else
		{t_ptr_liste local = file ;
		 while ( ! est_vide( queue_liste( local ) ) )
		       local = queue_liste( local ) ;
		 local->suiv = nouv ;
		 return( file ) ;
		}
	    }
