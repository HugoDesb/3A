#define tete_file tete_liste
#define defile queue_liste
t_ptr_liste enfile ( t_ptr_arbre val , t_ptr_liste liste ) ;

t_ptr_liste cree_vide ( void ) ;
int est_vide ( t_ptr_liste liste ) ;
t_ptr_liste ajout_liste ( t_ptr_arbre val , t_ptr_liste liste ) ;
t_ptr_arbre tete_liste ( t_ptr_liste liste ) ;
t_ptr_liste queue_liste ( t_ptr_liste liste ) ;

