
typedef struct mm
        {t_ptr_arbre element ;
         struct mm * suiv ;
        }
struct_liste , * t_ptr_liste ;
